module.exports = require("yargs-parser")(process.argv.slice(2));
